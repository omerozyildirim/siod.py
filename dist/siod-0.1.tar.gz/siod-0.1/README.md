# siod.py
Simple Input Output Dialog allows the programmer to define i/o dialog windows with a more intuitive syntax and a simpler structure than vanilla TkInter.
